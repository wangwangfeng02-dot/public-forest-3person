# GitHub Pages 部署说明

这个文件夹可直接上传到 GitHub Pages。真正需要发布的文件只有：

- `index.html`

## 部署步骤

1. 打开 GitHub，新建仓库，例如：`public-forest-3person`。
2. 上传 `index.html` 到仓库根目录。
3. 进入仓库 `Settings → Pages`。
4. Source 选择 `Deploy from a branch`。
5. Branch 选择 `main`，Folder 选择 `/root`。
6. 点击 Save。
7. 等待 1–3 分钟，GitHub 会生成网址：
   `https://你的用户名.github.io/public-forest-3person/`

数据仍会写入 Firebase Realtime Database。

## 测试

用三个浏览器窗口同时打开 GitHub Pages 网址，填写信息后测试三人匹配。
